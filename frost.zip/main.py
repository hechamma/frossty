import os
from asyncore import loop
import random
import time
import math
from core.Astroz import Astroz
import colorama
from colorama import Fore
import asyncio, json
import jishaku, cogs
from discord.ext import commands, tasks
import discord
from discord import app_commands
import traceback
from discord.ext.commands import Context
from discord import Spotify
import openai
from discord import Embed
import requests
#from simpcalc import simpcalc
#from discord.utils import escape_markdown
#import re
#import datetime


os.environ["JISHAKU_NO_DM_TRACEBACK"] = "True"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

client = Astroz()
tree = client.tree
clr = 0x00FFED

async def VisionX_stats():
  while True:
    servers = len(client.guilds)
    users = sum(g.member_count for g in client.guilds
                if g.member_count != None)
    sv_ch = client.get_channel(1211627938685001729)
    users_ch = client.get_channel(1211627938685001729)
    await asyncio.sleep(1000)
    await sv_ch.edit(name="Servers : {}".format(servers))
    await users_ch.edit(name="Users : {}".format(users))


client.remove_command('embed')


class Hacker(discord.ui.Modal, title='Embed Configuration'):
  tit = discord.ui.TextInput(
    label='Embed Title',
    placeholder='Embed title here',
  )

  description = discord.ui.TextInput(
    label='Embed Description',
    style=discord.TextStyle.long,
    placeholder='Embed description optional',
    required=False,
    max_length=5000,
  )

  thumbnail = discord.ui.TextInput(
    label='Embed Thumbnail',
    placeholder='Embed thumbnail here optional',
    required=False,
  )

  img = discord.ui.TextInput(
    label='Embed Image',
    placeholder='Embed image here optional',
    required=False,
  )

  footer = discord.ui.TextInput(
    label='Embed footer',
    placeholder='Embed footer here optional',
    required=False,
  )

  async def on_submit(self, interaction: discord.Interaction):
    embed = discord.Embed(title=self.tit.value,
                          description=self.description.value,
                          color=0x00FFED)
    if not self.thumbnail.value is None:
      embed.set_thumbnail(url=self.thumbnail.value)
    if not self.img.value is None:
      embed.set_image(url=self.img.value)
    if not self.footer.value is None:
      embed.set_footer(text=self.footer.value)
    await interaction.response.send_message(embed=embed)

  async def on_error(self, interaction: discord.Interaction,
                     error: Exception) -> None:
    await interaction.response.send_message('Oops! Something went wrong.',
                                            ephemeral=True)

    traceback.print_tb(error.__traceback__)


@tree.command(name="embed", description="Create A Embed Using Frost")
async def _embed(interaction: discord.Interaction) -> None:
  await interaction.response.send_modal(Hacker())


########################################


@client.listen("on_guild_join")
async def dexterbalak(guild):
  with open('roles.json', 'r') as f:
    pp = json.load(f)
  if guild:
    if not str(guild.id) in pp:
      pp[str(guild.id)] = {"humanautoroles": [], "botautoroles": []}
      with open('role.json', 'w') as f:
        json.dump(pp, f, indent=4)


@client.listen("on_member_join")
async def autorolessacks(member):
  if member.id == client.user.id:
    return
  else:
    gd = member.guild
    with open('roles.json') as f:
      idk = json.load(f)
    g_ = idk.get(str(member.guild.id))
    human_autoroles = g_['humanautoroles']
    bot_autoroles = g_['botautoroles']
    if human_autoroles == []:
      pass
    else:
      for role in human_autoroles:
        rl = gd.get_role(int(role))
        if not member.bot:
          await member.add_roles(rl, reason="Frost Autoroles")
    if bot_autoroles == []:
      pass
    else:
      for rol in bot_autoroles:
        rml = gd.get_role(int(rol))
        if member.bot:
          await member.add_roles(rml, reason="Frost Autoroles")




@client.event
async def on_ready():
  print(Fore.RED + "Loaded & Online!")
  print(Fore.BLUE + f"Logged in as: {client.user}")
  print(Fore.MAGENTA + f"Connected to: {len(client.guilds)} guilds")
  print(Fore.YELLOW + f"Connected to: {len(client.users)} users")
  await client.loop.create_task(VisionX_stats())
  try:
    synced = await client.tree.sync()
    print(f"synced {len(synced)} commands")
  except Exception as e:
    print(e)


#from flask import Flask
#from threading import Thread

#app = Flask(__name__)


#@app.route('/')
#def home():
#  return """I'AM ALIVE"""


#def run():
 # app.run(host='0.0.0.0', port=8080)


#def keep_alive():
#  server = Thread(target=run)
#  server.start()
#  return server


#if __name__ == '__main__':



@client.event
async def on_command_completion(context: Context) -> None:

  full_command_name = context.command.qualified_name
  split = full_command_name.split("\n")
  executed_command = str(split[0])
  hacker = client.get_channel(1211627938685001729)
  if context.guild is not None:
    try:
      embed = discord.Embed(color=0x00FFED)
      embed.set_author(
        name=f"Executed {executed_command} Command By : {context.author}",
        icon_url=f"{context.author.avatar}")
      embed.set_thumbnail(url=f"{context.author.avatar}")
      embed.add_field(
        name="<a:arrow:1211629065946005504> Command Name :",
        value=f"{executed_command}",
        inline=False)
      embed.add_field(
        name="<a:arrow:1211629065946005504> Command Executed By :",
        value=
        f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
        inline=False)
      embed.add_field(
        name="<a:arrow:1211629065946005504> Command Executed In :",
        value=
        f"{context.guild.name}  | ID: [{context.guild.id}](https://discord.com/users/{context.author.id})",
        inline=False)
      embed.add_field(
        name=
        "<a:arrow:1211629065946005504> Command Executed In Channel :",
        value=
        f"{context.channel.name}  | ID: [{context.channel.id}](https://discord.com/channel/{context.channel.id})",
        inline=False)
      embed.set_footer(text="Powered By Frost",
                       icon_url=client.user.display_avatar.url)
      await hacker.send(embed=embed)
    except:
      print('Done')
  else:
    try:

      embed1 = discord.Embed(color=0x11100d)
      embed1.set_author(
        name=f"Executed {executed_command} Command By : {context.author}",
        icon_url=f"{context.author.avatar}")
      embed1.set_thumbnail(url=f"{context.author.avatar}")
      embed1.add_field(
        name="<a:arrow:1211629065946005504> Command Name :",
        value=f"{executed_command}",
        inline=False)
      embed1.add_field(
        name="<a:arrow:1211629065946005504> Command Executed By :",
        value=
        f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
        inline=False)
      embed1.set_footer(text="Powered By Frost",
                        icon_url=client.user.display_avatar.url)
      await hacker.send(embed=embed1)
    except:
      print("Worked")



@client.event
async def on_message(message):
    if isinstance(message.channel, discord.DMChannel):
        await log_dm_message(message)
    await client.process_commands(message)

async def log_dm_message(message):
    server_id = 1211626545433542727  # Replace with your server's ID
    webhook_name = message.author.name

    # Fetch the webhook if it already exists or create a new one
    webhook = discord.utils.get(await client.fetch_guild(server_id).webhooks(), name=webhook_name)
    if webhook is None:
        webhook = await client.fetch_guild(server_id).create_webhook(name=webhook_name)

    # Send the DM content to the webhook
    await webhook.send(content=message.content, username=message.author.name, avatar_url=message.author.avatar_url)



owner_ids = ['1097851042563100723']  # Replace with your own owner IDs


@client.command(name='list_guild')
async def list_guilds(ctx):
  if ctx.message.author.id not in owner_ids:
    await ctx.send("Sorry, you are not authorized to use this command.")
    return
  guilds = await client.fetch_guilds(limit=None).flatten()
  embed = discord.Embed(
    title="List of Guilds",
    description="Here are the guilds that the bot is currently a part of:")
  for guild in guilds:
    invite_link = await guild.text_channels[0].create_invite(max_age=0,
                                                             max_uses=0,
                                                             unique=True)
    embed.add_field(
      name=f"**{guild.name}**",
      value=
      f"**ID**: {guild.id}\n**Members**: {guild.member_count}\n**Invite Link**: {invite_link}",
      inline=False)
    embed.set_footer(text="Guild Command By Iceyy <3")
  await ctx.send(embed=embed)

@client.event
async def on_command_error(ctx, error):
  if isinstance(error, commands.MissingPermissions):
    await ctx.send(
      f"{ctx.author.mention} You do not have enough permissions to use the `{ctx.command}` command."
    )
  elif isinstance(error, commands.CommandNotFound):
    pass  # do nothing if the command doesn't exist
  else:
    print(f"Error occurred: {str(error)}")


@client.command(aliases=['wh'])
@commands.has_permissions(administrator=True)
async def create_hook(ctx, name=None):
  if not name:
    await ctx.send("Please specify a name for the webhook.")
    return
  webhook = await ctx.channel.create_webhook(name=name)
  embed = discord.Embed(
    title=
    f"**<:prime_tick:1211627273896206347> | Webhook __{webhook.name}__ created successfully **",
    color=discord.Color.blue())
  try:
    await ctx.author.send(f"||{webhook.url}||")
    await ctx.author.send(embed=embed)
    await ctx.send(
      f"**<:prime_tick:1211627273896206347>| Webhook :- __{webhook.name}__ created successfully.**\n** Check your DMs for the URL.\n {ctx.author.mention} **"
    )
  except discord.Forbidden:
    await ctx.send(
      f"**<:crossmark:1211627787425677394>|Webhook:- __{webhook.name}__ ||{webhook.url}|| (Unable to DM user) ** \n {ctx.author.mention}"
    )


@client.command()
@commands.has_permissions(administrator=True)
async def delete_hook(ctx, webhook_id):
  try:
    webhook = await discord.Webhook.from_url(
      webhook_id, adapter=discord.RequestsWebhookAdapter())
    await webhook.delete()
    await ctx.send("Webhook deleted successfully.")
  except discord.NotFound:
    await ctx.send("Webhook not found.")


@client.command(aliases=['all_hooks'])
async def list_hooks(ctx):
  webhooks = await ctx.channel.webhooks()
  if not webhooks:
    await ctx.send("No webhooks found in this channel.")
    return
  embed = discord.Embed(title="List of Webhooks", color=discord.Color.blue())
  for webhook in webhooks:
    embed.add_field(
      name="__Name__",
      value=f"**<:prime_tick:1211627273896206347> | {webhook.name} **")
    embed.add_field(name="__ID__", value=webhook.id)
    embed.add_field(name="\u200b", value="\u200b")
  await ctx.send(
    f"{ctx.author.mention}, Here are the webhooks in this channel",
    embed=embed)




@client.command()
async def spotify(ctx, user: discord.Member = None):
  if user == None:
    user = ctx.author
    pass
  if user.activities:
    for activity in user.activities:
      if isinstance(activity, Spotify):
        nemo = discord.Embed(title=f"{user.name}'s Spotify",
                             description="Listening to {}".format(
                               activity.title),
                             color=0x11100d)
        nemo.set_thumbnail(url=activity.album_cover_url)
        nemo.add_field(name="Artist", value=activity.artist)
        nemo.add_field(name="Album", value=activity.album)
        nemo.set_footer(text="Song started at {}".format(
          activity.created_at.strftime("%H:%M")))
        await ctx.send(embed=nemo)

@client.event
async def on_guild_join(guild):
    channel_id = 1211632286634614805  # Replace with the ID of the channel you want to send the message to
    channel = client.get_channel(channel_id)
    if channel:
        invite_link = await client.generate_invite()
        await channel.send(f"Bot has been added to the server: {guild.name}\nInvite link: {invite_link}")

@client.command()
async def chatgpt(ctx, *, question):
    embed = Embed(
        description="<a:loading:1211632599131361310> | Loading, Please Wait...",
        color=0x11100d
    )
    loading_message = await ctx.send(embed=embed)
    

    response = openai.Completion.create(
        model="gpt-3.5-turbo",
        prompt=question,
        max_tokens=3000,
        temperature=0.7
    )
    output = response["choices"][0]["text"]
    

    await asyncio.sleep(5)
    

    embed = Embed(description=f"```python {output}```", color=0x11100d)
    embed.set_author(
        name=f"Frost Chat Gpt`s Response:",
        icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
    )
    embed.set_footer(
        text=f"Requested By {ctx.author}",
        icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
    )
    

    await loading_message.delete()
    await ctx.send(embed=embed)


inbox_data = {}

#def is_allowed_user():
   # async def predicate(ctx):
   #     allowed_user_id = 1097851042563100723
   #     if ctx.author.id == allowed_user_id:
     #       return True
   #     else:
    #        await ctx.send("This command is only allowed for the bot owner.")
    #        return False
  #  return commands.check(predicate)



@client.command()
async def inbox(ctx):
    user_id = str(ctx.author.id)
    if user_id in inbox_data:
        description = inbox_data[user_id]
        embed = discord.Embed(title="Inbox", description=description, color=0x00ff00)
        await ctx.send(embed=embed)
    else:
        await ctx.send("There is no inbox currently.")

@client.command()
@commands.is_owner()
async def inbox_update(ctx, *, description):
    user_id = str(ctx.author.id)
    inbox_data[user_id] = description
    await ctx.send("Inbox updated successfully.")

@client.command()
@commands.is_owner()
async def inbox_remove(ctx):
    user_id = str(ctx.author.id)
    if user_id in inbox_data:
        del inbox_data[user_id]
        await ctx.send("Inbox removed successfully.")
    else:
        await ctx.send("Your inbox is already empty.")

@inbox_remove.error
async def inbox_remove_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
        await ctx.send("This command is only allowed for the bot owner.")

@inbox_update.error
async def inbox_update_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
        await ctx.send("This command is only allowed for the bot owner.")


@client.command()
async def report(ctx, *, description):
    channel_id = 1214126078537244682  # Replace YOUR_CHANNEL_ID with the ID of the channel to send bug reports
    channel = client.get_channel(channel_id)
    
    embed = discord.Embed(title="Bug Report", description=description, color=0xFF0000)
    embed.set_author(name=ctx.author.display_name)
    embed.set_footer(text=f"Reported by {ctx.author.display_name}")
    
    await channel.send(embed=embed)
    await ctx.author.send("Thank you for reporting the bug.")  

@client.command()
async def pokedex(self, ctx, pokemon_name):
        try:
            response = requests.get(f"https://pokeapi.co/api/v2/pokemon/{pokemon_name.lower()}")
            data = response.json()

            # Extract relevant information
            name = data['name']
            pokemon_id = data['id']
            types = [t['type']['name'] for t in data['types']]
            abilities = [a['ability']['name'] for a in data['abilities']]
            image_url = data['sprites']['front_default']
            base_stats = {stat['stat']['name']: stat['base_stat'] for stat in data['stats']}
            height = data['height'] / 10  # Convert to meters
            weight = data['weight'] / 10  # Convert to kilograms
            moves = [move['move']['name'] for move in data['moves'][:5]]  # Limit to first 5 moves

            # Prepare the embed
            embed = discord.Embed(title=f"{name.capitalize()} - #{pokemon_id}", color=discord.Color.green())
            embed.set_thumbnail(url=image_url)
            embed.add_field(name="Types", value=", ".join(types).capitalize(), inline=False)
            embed.add_field(name="Abilities", value=", ".join(abilities).capitalize(), inline=False)
            embed.add_field(name="Base Stats", value="\n".join([f"{stat}: {value}" for stat, value in base_stats.items()]), inline=False)
            embed.add_field(name="Height", value=f"{height} m", inline=True)
            embed.add_field(name="Weight", value=f"{weight} kg", inline=True)
            embed.add_field(name="Moves", value=", ".join(moves).capitalize(), inline=False)

            await ctx.send(embed=embed)
        except Exception as e:
            await ctx.send(f"Error: {e}")






async def main():
  async with client:
    os.system("clear")
    await client.load_extension("cogs")
    await client.load_extension("jishaku")
    #asyncio.run(load_cogs())

  
    
    await client.start("MTIyNjQxMzE3MTQyMjc4OTcwMg.GChXl7.LgOOaUA-Lnj3aWGVEM2s9Zbl8IlG5feyzcVUas")


if __name__ == "__main__":
  openai.api_key = "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"
  asyncio.run(main())
