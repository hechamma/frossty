import discord
from discord.ext import commands
from discord.ui import Button, View
import requests

# Helper function to get cryptocurrency prices
def get_crypto_prices():
    btc_price = requests.get('https://api.coinbase.com/v2/prices/BTC-USD/spot').json()['data']['amount']
    ltc_price = requests.get('https://api.coinbase.com/v2/prices/LTC-USD/spot').json()['data']['amount']
    return btc_price, ltc_price

# This is the cog that contains the cryptocurrency commands
class crypto(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Command to display cryptocurrency prices
    @commands.command()
    async def crypto_price(self, ctx):
        btc_price, ltc_price = get_crypto_prices()
        message_content = f'<:sparkles:1227180894029086730> The current price of Bitcoin is `{btc_price}$`\n<:sparkles:1227180894029086730> Litecoin is `{ltc_price}$`'
        await ctx.send(message_content, view=self.crypto_buttons())

    # This function creates the buttons view
    def crypto_buttons(self):
        view = View()

        # Button for refreshing crypto prices
        refresh_button = Button(label='Refresh', style=discord.ButtonStyle.green)
        refresh_button.callback = self.refresh_prices_callback
        view.add_item(refresh_button)

        return view

    # Callback for the refresh button
    async def refresh_prices_callback(self, interaction):
        btc_price, ltc_price = get_crypto_prices()
        message_content = f'<:sparkles:1227180894029086730> The current price of Bitcoin is `{btc_price}$`\n<:sparkles:1227180894029086730> Litecoin is `{ltc_price}$`'
        await interaction.response.edit_message(content=message_content)

# Setup function to add the cog to the bot
def setup(bot):
    bot.add_cog(crypto(bot))
