import discord
from discord.ext import commands


class owner2(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Owner commands"""
  
    def help_custom(self):
		      emoji = '<:icons_owner:1226774131903565825> '
		      label = "Owner"
		      description = "Only owner of the bot can use these commands"
		      return emoji, label, description

    @commands.group()
    async def __Owner__(self, ctx: commands.Context):
        """```eval , shutdown , slist , restart , sync , np , np add , np remove , np list , bl show , bl add , bl remove , bdg , bdg add , bdg remove , dm , nick , globalban , inbox_update , inbox_remove```"""