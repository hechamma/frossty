import discord
from discord.ext import commands


class media1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Media Commands"""
  
    def help_custom(self):
		      emoji = '<:icon_camera:1226772343704129599>'
		      label = "Media"
		      description = "Media Commands"
		      return emoji, label, description

    @commands.group()
    async def __Media__(self, ctx: commands.Context):
        """```media, media setup, media remove, media config, media reset```"""