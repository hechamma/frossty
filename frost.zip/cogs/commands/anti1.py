import discord
from discord.ext import commands


class anti1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """AntiNuke Commands"""
  
    def help_custom(self):
		      emoji = '<:ExoticAntinuke:1219215051379183657>'
		      label = "AntiNuke"
		      description = "Antinuke Commands"
		      return emoji, label, description

    @commands.group()
    async def __AntiNuke__(self, ctx: commands.Context):
        """```antinuke , antinuke enable , antinuke disable , antinuke show , antinuke punishment set , antinuke whitelist add , antinuke whitelist remove , antinuke whitelist show , antinuke whitelist reset , antinuke channelclean , antinuke roleclean , antinuke wl role```"""