import discord
from discord.ext import commands


class joindm1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Join Dm Commands"""
  
    def help_custom(self):
		      emoji = '<:icons_letters:1226770856546668575>'
		      label = "Join Dm"
		      description = "Join Dm Commands"
		      return emoji, label, description

    @commands.group()
    async def __joindm1__(self, ctx: commands.Context):
        """```joindm enable, joindm disable, joindm message```"""