import discord
from discord.ext import commands


class fun1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Fun Commands"""
  
    def help_custom(self):
		      emoji = '<:premium:1220691913246638120> '
		      label = "Fun"
		      description = "Fun Commands"
		      return emoji, label, description

    @commands.group()
    async def __Fun__(self, ctx: commands.Context):
        """```pokedex , tickle , kiss , hug , slap , pat , feed , pet , howgay , slots , penis , meme , cat , iplookup , nitro```"""