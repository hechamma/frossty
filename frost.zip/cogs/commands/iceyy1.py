import discord
from discord.ext import commands


class iceyy1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Crypto Commands"""
  
    def help_custom(self):
		      emoji = '<:icon_coin:1227180057009590272>'
		      label = "Crypto"
		      description = "Crypto Commands "
		      return emoji, label, description

    @commands.group()
    async def __Iceyy__(self, ctx: commands.Context):
        """```crypto_price```"""