import discord
from discord.ext import commands


class gw1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Giveaway Commands"""
  
    def help_custom(self):
		      emoji = '<:LM_Icon_Gift:1226770312935243796>'
		      label = "Giveaway"
		      description = "Giveaway Commands"
		      return emoji, label, description

    @commands.group()
    async def __Giveaway__(self, ctx: commands.Context):
        """```gstart , gend , greroll```"""