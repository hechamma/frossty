import discord
from discord.ext import commands
from discord.ui import Button, Select, View

class LatencyView(View):
    def __init__(self, bot):
        super().__init__(timeout=None)  # Set timeout to None to make the view persistent
        self.bot = bot

    @discord.ui.button(label='Refresh', style=discord.ButtonStyle.green, emoji='<:refresh:1219602732374167552>')
    async def refresh_button(self, interaction: discord.Interaction, button: Button):
        latency = round(self.bot.latency * 1000)
        embed = discord.Embed(title='Bot Latency', description=f'🏓 Pong! {latency}ms', color=discord.Color.blue())
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.select(placeholder='Choose latency type...', min_values=1, max_values=1,
                       options=[
                           discord.SelectOption(label='API Latency', description='Check the API latency', emoji='🌐'),
                           discord.SelectOption(label='Database Latency', description='Check the database latency', emoji='💾'),
                           discord.SelectOption(label='Custom Latency', description='Check a custom latency', emoji='⚙️')
                       ])
    async def latency_select(self, interaction: discord.Interaction, select: Select):
        if select.values[0] == 'API Latency':
            latency = round(self.bot.latency * 1000)
            description = f'API Latency: {latency}ms'
        elif select.values[0] == 'Database Latency':
            # Replace with actual database latency check
            latency = 50  # Placeholder value
            description = f'Database Latency: {latency}ms'
        elif select.values[0] == 'Cu':
            # Replace with actual custom latency check
            latency = 100  # Placeholder value
            description = f'Custom Latency: {latency}ms'

        embed = discord.Embed(title='Bot Latency', description=description, color=discord.Color.blue())
        await interaction.response.edit_message(embed=embed, view=self)

class LatencyCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(Alisaes=['latency'])
    async def ping(self, ctx):
        latency = round(self.bot.latency * 1000)
        embed = discord.Embed(title='Bot Latency', description=f'🏓 Pong! {latency}ms', color=discord.Color.blue())
        view = LatencyView(self.bot)
        await ctx.send(embed=embed, view=view)

def setup(bot):
    bot.add_cog(LatencyCog(bot))
  